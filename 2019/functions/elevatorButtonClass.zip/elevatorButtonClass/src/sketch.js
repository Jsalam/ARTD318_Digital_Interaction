//Elevator
let elevator;

// buttons
let button1;
let button2;


// images
let iPhoneX;

let dante;
let danteOver;
let danteSliding;

// touchDetection
var isTouchDevice;

// Here we import all the images and sounds into the project
function preload(){
	// Load images
	iPhoneX = loadImage("img/iPhoneX_mockup.png");
	dante = loadImage("img/dante.png");
	danteOver = loadImage("img/danteOver.png");
	danteSliding = loadImage("img/danteSliding.png");

}

// Here we setup the canvas
function setup(){
	// Create a canvas
	let canvas = createCanvas(900,1200);
	// Anchor canvas to specific location on HTML file
	canvas.parent("#sketch_Location"); // This video explains this part: https://www.youtube.com/watch?v=eoXLD0Aw1YI
	// detect if The device is a touch screen
	isTouchDevice = (navigator.maxTouchPoints || 'ontouchstart' in document.documentElement);
	// instantiate Elevator
	elevator = new Elevator(this,600,20, 2);
	// instantiate buttons
	button1 = new Button(this,40, 120, 470, 180, dante, danteOver, danteSliding);
}

// Here we draw all the elements on the canvas
function draw(){
	// Set the background
	background(255);
	button1.show(elevator.getYCoord());

	// Elevator
	elevator.descend();

	// iPhone Skin
	if (!isTouchDevice){
		image(iPhoneX, 0, 0, 552, 1200)
	}
}

function touchStarted(){
	elevator.updateTouch();
	button1.updateTouch();
}
